#include "game.hpp"

int main() {
    Game game;
    game.play();
    return 0;
}