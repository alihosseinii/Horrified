#ifndef GAME_HPP
#define GAME_HPP

class Game {
public:
    void play();
};

#endif